package simwinter;

import java.math.BigDecimal;

public class NeoPositionInput {


}
