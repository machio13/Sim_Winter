package simwinter.trade;

public enum TradeSide {
    Sell,
    Buy;
}
